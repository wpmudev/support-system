<div class="wrap">
	<?php include( 'ticket-status-links.php' ); ?>
	<?php include( 'tickets-table-form.php' ); ?>
</div>