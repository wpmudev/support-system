<form id="support-faqs" method="post">
	<?php $table->search_box( __( 'Search FAQs', INCSUB_SUPPORT_LANG_DOMAIN ), 's' ); ?>
	<?php $table->display(); ?>
</form>